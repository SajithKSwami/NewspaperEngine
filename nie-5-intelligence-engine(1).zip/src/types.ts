/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface Entity {
  name: string;
  type: 'person' | 'organization' | 'country' | 'city' | 'company';
}

export interface Event {
  id: string;
  type: string;
  description: string;
  date: string;
  actors: string[];
  locations: string[];
}

export interface Relationship {
  entity_a: string;
  entity_b: string;
  relationship_type: string;
  evidence: string;
  confidence: number;
}

export interface RiskSignal {
  id: string;
  label: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
  description: string;
  category: string;
}

export interface ArticleMetadata {
  article_id: string;
  source: string;
  url: string;
  title: string;
  published_date: string;
  summary: string;
  entities: {
    people: string[];
    organizations: string[];
    countries: string[];
    cities: string[];
    companies: string[];
  };
  events: Event[];
  relationships: Relationship[];
  topics: string[];
  sectors: string[];
  geopolitical_relevance: string[];
  economic_relevance: string[];
  risk_signals: RiskSignal[];
  opportunity_signals: string[];
}

export interface ScanResult {
  timestamp: string;
  articles: ArticleMetadata[];
  connections: Relationship[];
}
