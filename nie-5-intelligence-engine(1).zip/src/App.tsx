import React, { useState, useEffect } from 'react';
import { 
  Database, 
  Search, 
  Cpu, 
  Activity, 
  Globe, 
  Zap, 
  ShieldAlert, 
  TrendingUp, 
  Share2, 
  Layers,
  RefreshCw,
  Clock,
  ExternalLink,
  ChevronRight,
  Filter
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { format } from 'date-fns';
import { ArticleMetadata, ScanResult, RiskSignal } from './types';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';
import { GoogleGenAI } from "@google/genai";

// Initialize Gemini in frontend
const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// Sidebar Component (Nav Rail)
const NavRail = ({ activeTab, setActiveTab }: { activeTab: string, setActiveTab: (t: string) => void }) => {
  const tabs = [
    { id: 'intelligence', icon: Database, label: 'Intelligence' },
    { id: 'connections', icon: Share2, label: 'Signals' },
    { id: 'entities', icon: Layers, label: 'Entities' },
    { id: 'risks', icon: ShieldAlert, label: 'Risks' },
  ];

  return (
    <aside className="w-[60px] bg-white border-r border-border-dim flex flex-col items-center py-5 gap-6 h-full">
      {tabs.map((tab) => (
        <button
          key={tab.id}
          onClick={() => setActiveTab(tab.id)}
          title={tab.label}
          className={cn(
            "w-8 h-8 rounded shrink-0 transition-colors flex items-center justify-center border",
            activeTab === tab.id 
              ? "bg-ink border-ink text-white" 
              : "bg-[#F4F4F2] border-border-dim text-slate-500 hover:border-ink hover:text-ink"
          )}
        >
          <tab.icon className="w-4 h-4" />
        </button>
      ))}
      
      <div className="mt-auto mb-5">
        <button className="w-8 h-8 rounded-full bg-[#F4F4F2] border border-border-dim flex items-center justify-center text-slate-400">
           <div className="w-3 h-3 bg-ink rounded-full" />
        </button>
      </div>
    </aside>
  );
};

// Main Feed Item
interface FeedItemProps {
  article: ArticleMetadata;
  onSelect: () => void;
  isSelected: boolean;
  key?: string | number;
}

const FeedItem = ({ article, onSelect, isSelected }: FeedItemProps) => {
  return (
    <div
      onClick={onSelect}
      className={cn(
        "p-5 cursor-pointer border-b border-[#EEE] transition-colors",
        isSelected ? "bg-white" : "bg-transparent hover:bg-white/50"
      )}
    >
      <div className="flex justify-between items-center mb-2">
        <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{article.source}</span>
        <span className="text-[9px] font-mono text-slate-400">{format(new Date(article.published_date), 'HH:mm')}</span>
      </div>
      <h3 className={cn(
        "text-sm font-bold leading-tight mb-2 font-serif",
        isSelected ? "text-ink" : "text-slate-600"
      )}>
        {article.title}
      </h3>
      <p className="text-[11px] text-slate-500 line-clamp-2 leading-relaxed">{article.summary}</p>
    </div>
  );
};

// Risk Detail Modal
const RiskModal = ({ risk, onClose, onFilter }: { risk: RiskSignal | null, onClose: () => void, onFilter: (l: string) => void }) => {
  if (!risk) return null;

  return (
    <AnimatePresence>
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-50 flex items-center justify-center p-6 bg-ink/40 backdrop-blur-sm"
        onClick={onClose}
      >
        <motion.div 
          initial={{ scale: 0.95, y: 20 }}
          animate={{ scale: 1, y: 0 }}
          exit={{ scale: 0.95, y: 20 }}
          className="w-full max-w-md bg-white border border-border-dim shadow-2xl p-8 relative"
          onClick={e => e.stopPropagation()}
        >
          <button 
            onClick={onClose}
            className="absolute top-4 right-4 text-slate-400 hover:text-ink transition-colors"
          >
            <RefreshCw className="w-4 h-4 rotate-45" />
          </button>

          <div className="mb-6">
            <div className="flex items-center gap-2 mb-2">
              <span className="text-[10px] font-bold uppercase tracking-widest text-slate-400">Risk Intelligence Unit</span>
              <div className="h-px flex-1 bg-slate-100" />
            </div>
            <h2 className="font-serif text-2xl font-bold text-ink leading-tight">{risk.label}</h2>
          </div>

          <div className="grid grid-cols-2 gap-4 mb-8">
            <div className="p-3 bg-bg-base border border-border-dim rounded">
              <span className="text-[8px] font-bold uppercase text-slate-500 block mb-1">Severity</span>
              <div className={cn(
                "text-xs font-bold uppercase",
                risk.severity === 'critical' ? 'text-rose-600' :
                risk.severity === 'high' ? 'text-rose-500' :
                risk.severity === 'medium' ? 'text-orange-500' : 'text-slate-600'
              )}>
                {risk.severity} Profile
              </div>
            </div>
            <div className="p-3 bg-bg-base border border-border-dim rounded">
              <span className="text-[8px] font-bold uppercase text-slate-500 block mb-1">Category</span>
              <div className="text-xs font-bold uppercase text-ink">{risk.category}</div>
            </div>
          </div>

          <div className="mb-8">
             <span className="text-[10px] font-bold uppercase tracking-widest text-slate-400 block mb-3">Technical Description</span>
             <p className="text-sm text-slate-600 leading-relaxed font-serif italic border-l-2 border-slate-100 pl-4">
               {risk.description}
             </p>
          </div>

          <button 
            onClick={() => {
              onFilter(risk.label);
              onClose();
            }}
            className="w-full h-12 bg-ink text-white font-bold uppercase text-[11px] tracking-widest hover:bg-slate-800 transition-all flex items-center justify-center gap-2"
          >
            <Search className="w-3.5 h-3.5" />
            View Related Intelligence
          </button>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
};

// ... (previous imports and helpers)

// Intelligence Details (Newspaper Canvas)
const DetailView = ({ article, onFilterByLabel }: { article: ArticleMetadata | null, onFilterByLabel: (label: string) => void }) => {
  const [selectedRisk, setSelectedRisk] = useState<RiskSignal | null>(null);

  if (!article) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center text-slate-400 font-mono text-[10px] uppercase tracking-widest">
        <div className="w-12 h-px bg-border-dim mb-4" />
        Waiting for Input Signal
      </div>
    );
  }

  return (
    <div className="flex-1 overflow-y-auto p-12 flex justify-center bg-bg-workspace items-start relative">
      <RiskModal 
        risk={selectedRisk} 
        onClose={() => setSelectedRisk(null)} 
        onFilter={onFilterByLabel}
      />
      
      {/* Guideline Decorations */}
      <div className="absolute left-1/2 top-0 w-px h-full bg-blue-500/10 pointer-events-none" />
      <div className="absolute top-1/2 left-0 w-full h-px bg-blue-500/10 pointer-events-none" />

      <motion.div 
        key={article.article_id}
        initial={{ opacity: 0, scale: 0.98 }}
        animate={{ opacity: 1, scale: 1 }}
        className="w-[600px] min-h-[800px] bg-white shadow-[0_10px_30px_rgba(0,0,0,0.08)] p-12 flex flex-col relative"
      >
        <header className="text-center pb-2 mb-6 border-b-2 border-ink">
          <h1 className="font-serif text-5xl uppercase tracking-tighter mb-1">NIE-5 CHRONICLE</h1>
          <div className="border-t border-b border-ink py-1 flex justify-between text-[10px] font-bold uppercase">
            <span>INTEL-GEN: VER 5.0</span>
            <span>{format(new Date(article.published_date), 'EEEE, MMMM dd, yyyy')}</span>
            <span>SIGNAL-ID: {article.article_id.slice(-8)}</span>
          </div>
        </header>

        <div className="grid grid-cols-3 gap-6 flex-1">
          <div className="col-span-2">
             <div className="font-serif text-[32px] leading-[1.1] mb-4 font-bold tracking-tight text-ink">
               {article.title}
             </div>
             
             <div className="w-full aspect-[16/10] bg-[#EAEAEA] mb-4 flex items-center justify-center text-[11px] text-slate-400 uppercase font-mono tracking-widest border border-slate-200">
               {article.source} Feature Image Signal
             </div>

             <div className="font-serif text-[13px] leading-relaxed text-ink space-y-4 text-justify">
               <p className="first-letter:text-4xl first-letter:float-left first-letter:mr-2 first-letter:font-bold first-letter:leading-[0.8] first-letter:mt-1">
                 {article.summary}
               </p>
               
               {article.relationships.length > 0 && (
                 <div className="p-4 bg-[#F9F9F7] border-l-4 border-ink font-sans text-xs italic">
                   Expert Analysis Connection: {article.relationships[0].entity_a} was linked to {article.relationships[0].entity_b} via "{article.relationships[0].relationship_type}".
                 </div>
               )}
             </div>
          </div>

          <div className="border-l border-border-dim pl-6 flex flex-col gap-8">
            <section>
              <h4 className="text-[10px] font-bold uppercase tracking-widest text-slate-400 mb-3 pb-1 border-b border-slate-100">Entities</h4>
              <div className="space-y-3">
                {Object.entries(article.entities).map(([type, list]) => 
                  list.length > 0 && (
                    <div key={type}>
                      <span className="text-[8px] uppercase text-slate-400 font-bold block mb-1">{type}</span>
                      <div className="flex flex-wrap gap-1">
                        {list.slice(0, 5).map((e: any) => (
                          <span key={e} className="px-1.5 py-0.5 bg-bg-base text-ink text-[10px] rounded-[2px]">{e}</span>
                        ))}
                      </div>
                    </div>
                  )
                )}
              </div>
            </section>

            <section>
              <h4 className="text-[10px] font-bold uppercase tracking-widest text-slate-400 mb-3 pb-1 border-b border-slate-100">Indicators</h4>
              <div className="space-y-4">
                <div className="group">
                  <div className="text-[10px] font-bold text-ink uppercase mb-1">Geopolitical</div>
                  <div className="text-[11px] text-slate-500 leading-tight italic">{article.geopolitical_relevance.join(', ') || 'Neutral'}</div>
                </div>
                <div>
                  <div className="text-[10px] font-bold text-rose-600 uppercase mb-1">Risk Assessment</div>
                  <div className="space-y-2">
                    {article.risk_signals.length > 0 ? (
                      article.risk_signals.map((risk) => (
                        <div 
                          key={risk.id}
                          className="p-2 rounded border border-slate-100 bg-[#FFF5F5] cursor-pointer hover:border-rose-300 transition-colors group/risk"
                          onClick={() => setSelectedRisk(risk)}
                        >
                          <div className="flex items-center justify-between mb-1">
                            <span className="text-[9px] font-bold uppercase text-rose-700">{risk.category}</span>
                            <span className={cn(
                              "text-[8px] font-bold uppercase px-1 rounded",
                              risk.severity === 'critical' ? 'bg-rose-600 text-white' :
                              risk.severity === 'high' ? 'bg-rose-500 text-white' :
                              risk.severity === 'medium' ? 'bg-orange-400 text-white' : 'bg-slate-400 text-white'
                            )}>
                              {risk.severity}
                            </span>
                          </div>
                          <div className="text-[11px] font-bold text-ink leading-tight">{risk.label}</div>
                        </div>
                      ))
                    ) : (
                      <div className="text-[11px] text-slate-500 leading-tight font-serif italic">Nominal Range</div>
                    )}
                  </div>
                </div>
                <div>
                  <div className="text-[10px] font-bold text-emerald-600 uppercase mb-1">Opportunity</div>
                  <div className="text-[11px] text-slate-500 leading-tight font-serif">{article.opportunity_signals.join(', ') || 'Restricted Signal'}</div>
                </div>
              </div>
            </section>

            <div className="mt-auto pt-6 border-t border-slate-100">
               <div className="text-[9px] font-mono text-slate-400 leading-tight">
                 SCAN_CONFIDENCE_LEVEL: 0.942<br/>
                 AI_MODEL: GEMINI-3-FLASH<br/>
                 TEMPORAL_NORM: {format(new Date(article.published_date), 'HH:mm:ss')}
               </div>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
};

export default function App() {
  const [activeTab, setActiveTab] = useState('intelligence');
  const [data, setData] = useState<ScanResult | null>(null);
  const [selectedArticle, setSelectedArticle] = useState<ArticleMetadata | null>(null);
  const [isScanning, setIsScanning] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const sources = Array.from(new Set(data?.articles?.map(a => a.source) || []));
  const sectors = Array.from(new Set(data?.articles?.flatMap(a => a.sectors) || []));
  const topics = Array.from(new Set(data?.articles?.flatMap(a => a.topics) || []));

  const [filterSource, setFilterSource] = useState('all');
  const [filterSector, setFilterSector] = useState('all');
  const [filterTopic, setFilterTopic] = useState('all');

  const filteredArticles = data?.articles?.filter(article => {
    const matchesSearch = article.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      article.summary.toLowerCase().includes(searchQuery.toLowerCase()) ||
      article.source.toLowerCase().includes(searchQuery.toLowerCase()) ||
      article.risk_signals.some(r => r.label.toLowerCase().includes(searchQuery.toLowerCase()));
    
    const matchesSource = filterSource === 'all' || article.source === filterSource;
    const matchesSector = filterSector === 'all' || article.sectors.includes(filterSector);
    const matchesTopic = filterTopic === 'all' || article.topics.includes(filterTopic);

    return matchesSearch && matchesSource && matchesSector && matchesTopic;
  }) || [];

  const fetchNews = async () => {
    try {
      const res = await fetch('/api/news');
      const json = await res.json();
      setData(json);
      if (json.articles?.length > 0 && !selectedArticle) {
        setSelectedArticle(json.articles[0]);
      }
    } catch (err) {
      console.error(err);
    }
  };

  const processArticleWithAI = async (article: any) => {
    const prompt = `
      You are NIE-5, a factual news intelligence system.
      Goal: Given a news article, you must summarize it and extract structured metadata.
      Avoid hallucinations. Return ONLY valid JSON.

      Input article:
      SOURCE: ${article.source}
      URL: ${article.link}
      TITLE: ${article.title}
      TEXT: """${article.content.substring(0, 3000)}"""

      Return ONLY valid JSON with this schema:
      {
        "article_id": "${article.source.replace(/\s+/g, '')}_${Date.now()}",
        "source": "${article.source}",
        "url": "${article.link}",
        "title": "${article.title}",
        "published_date": "${article.published_date}",
        "summary": "50-120 word neutral summary",
        "entities": {
          "people": [],
          "organizations": [],
          "countries": [],
          "cities": [],
          "companies": []
        },
        "events": [
          { "id": "ev_1", "type": "string", "description": "string", "date": "string", "actors": [], "locations": [] }
        ],
        "relationships": [
          { "entity_a": "string", "entity_b": "string", "relationship_type": "string", "evidence": "string", "confidence": 0.0 }
        ],
        "topics": [],
        "sectors": [],
        "geopolitical_relevance": [],
        "economic_relevance": [],
        "risk_signals": [
          { "id": "risk_1", "label": "string", "severity": "low|medium|high|critical", "description": "string", "category": "string" }
        ],
        "opportunity_signals": []
      }
    `;

    try {
      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: prompt
      });
      const text = response.text || "";
      const cleanJson = text.replace(/```json|```/g, "").trim();
      return JSON.parse(cleanJson);
    } catch (e) {
      console.error("Gemini error:", e);
      return null;
    }
  };

  const handleScan = async () => {
    setIsScanning(true);
    try {
      // Get raw articles from server
      const res = await fetch('/api/raw-feeds');
      const rawArticles = await res.json();
      
      const processedResults = [];
      for (const article of rawArticles) {
        const meta = await processArticleWithAI(article);
        if (meta) {
          processedResults.push(meta);
        }
      }

      // Save back to server
      const saveRes = await fetch('/api/save-news', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ articles: processedResults })
      });
      const finalData = await saveRes.json();
      setData(finalData);
    } catch (err) {
      console.error(err);
    } finally {
      setIsScanning(false);
    }
  };

  useEffect(() => {
    fetchNews();
  }, []);

  return (
    <div className="flex flex-col h-screen overflow-hidden text-ink font-sans bg-bg-base border border-border-dim">
      {/* Header Bar */}
      <header className="h-[56px] bg-white border-b border-border-dim flex items-center justify-between px-5 shrink-0 z-20">
        <div className="flex items-center gap-3">
          <div className="w-6 h-6 bg-ink rounded-[3px] flex items-center justify-center">
             <Cpu className="w-4 h-4 text-white" />
          </div>
          <span className="font-bold text-sm tracking-tight uppercase">NIE-5 Engine Intelligence</span>
          <span className="px-1.5 py-0.5 bg-bg-base text-[9px] rounded-sm font-bold uppercase text-slate-500">V.5.0.0</span>
        </div>

        <div className="flex items-center gap-4 flex-1 justify-center max-w-md mx-auto">
          <div className="relative w-full group">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 group-focus-within:text-ink transition-colors" />
            <input 
              type="text"
              placeholder="FILTER INTELLIGENCE STREAM..." 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-[#F4F4F2] border border-border-dim rounded-[4px] pl-9 pr-3 py-1.5 text-[11px] font-mono tracking-tight focus:outline-none focus:border-ink transition-all"
            />
          </div>
        </div>

        <div className="flex gap-6 text-[12px] font-bold text-ink uppercase tracking-tight">
          <span className="cursor-pointer hover:opacity-70">Archive</span>
          <span className="cursor-pointer hover:opacity-70">Patterns</span>
          <span className="cursor-pointer hover:opacity-70 text-blue-600">Live Preview</span>
        </div>

        <button 
          onClick={handleScan}
          disabled={isScanning}
          className="bg-ink text-white h-[32px] px-6 flex items-center justify-center text-[11px] font-bold uppercase tracking-wide rounded-[4px] hover:bg-slate-800 transition-all disabled:opacity-50 ml-4"
        >
          {isScanning ? 'Syncing...' : 'Initiate Briefing'}
        </button>
      </header>

      <div className="flex-1 flex overflow-hidden">
        <NavRail activeTab={activeTab} setActiveTab={setActiveTab} />
        
        {/* Intelligence Stream */}
        <aside className="w-[320px] bg-white border-r border-border-dim flex flex-col h-full overflow-hidden shrink-0">
          <div className="p-4 border-b border-border-dim flex flex-col gap-3 bg-white z-10 shrink-0">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-bold text-slate-400 uppercase tracking-[0.1em]">Analytic Feed ({filteredArticles.length})</span>
              <Filter className="w-3 h-3 text-slate-400" />
            </div>
            
            <div className="grid grid-cols-3 gap-2">
              <select 
                value={filterSource}
                onChange={(e) => setFilterSource(e.target.value)}
                className="bg-[#F4F4F2] border border-border-dim rounded-[4px] px-1 py-1 text-[8px] font-bold uppercase tracking-wider focus:outline-none focus:border-ink overflow-hidden text-ellipsis whitespace-nowrap"
              >
                <option value="all">Sources</option>
                {sources.map(s => <option key={s} value={s}>{s}</option>)}
              </select>
              <select 
                value={filterSector}
                onChange={(e) => setFilterSector(e.target.value)}
                className="bg-[#F4F4F2] border border-border-dim rounded-[4px] px-1 py-1 text-[8px] font-bold uppercase tracking-wider focus:outline-none focus:border-ink overflow-hidden text-ellipsis whitespace-nowrap"
              >
                <option value="all">Sectors</option>
                {sectors.map(s => <option key={s} value={s}>{s}</option>)}
              </select>
              <select 
                value={filterTopic}
                onChange={(e) => setFilterTopic(e.target.value)}
                className="bg-[#F4F4F2] border border-border-dim rounded-[4px] px-1 py-1 text-[8px] font-bold uppercase tracking-wider focus:outline-none focus:border-ink overflow-hidden text-ellipsis whitespace-nowrap"
              >
                <option value="all">Topics</option>
                {topics.map(t => <option key={t} value={t}>{t}</option>)}
              </select>
            </div>
          </div>
          
          <div className="flex-1 overflow-y-auto bg-slate-50/30">
            {filteredArticles.map((article: ArticleMetadata) => (
              <FeedItem 
                key={article.article_id} 
                article={article} 
                onSelect={() => setSelectedArticle(article)}
                isSelected={selectedArticle?.article_id === article.article_id}
              />
            ))}
            {(!data || filteredArticles.length === 0) && !isScanning && (
              <div className="p-10 text-center text-slate-400 italic text-[11px] uppercase tracking-widest font-mono">
                {searchQuery ? 'No matching signals.' : 'Buffer empty.'}
              </div>
            )}
            {isScanning && (
              <div className="p-10 text-center">
                <div className="w-6 h-6 border-2 border-ink border-t-transparent rounded-full animate-spin mx-auto mb-4" />
                <p className="text-[10px] text-slate-500 font-mono tracking-widest">INGESTING RSS DATA...</p>
              </div>
            )}
          </div>
          
          <div className="p-4 border-t border-border-dim bg-[#F4F4F2] mt-auto shrink-0">
             <div className="text-[9px] font-bold text-slate-400 uppercase mb-2 tracking-widest">Engine Status</div>
             <div className="flex justify-between items-center text-[10px]">
               <span className="text-slate-500">Latency</span>
               <span className="text-emerald-600 font-mono font-bold">12ms</span>
             </div>
          </div>
        </aside>

        {/* Detailed Content Workspace */}
        <main className="flex-1 flex flex-col bg-bg-workspace overflow-hidden">
          <DetailView 
            article={selectedArticle} 
            onFilterByLabel={(label) => {
              setSearchQuery(label);
              setActiveTab('intelligence');
            }}
          />
        </main>
      </div>

      <footer className="h-8 bg-ink border-t border-border-dim flex items-center px-4 text-[10px] text-slate-500 tracking-[0.1em] uppercase shrink-0 font-mono">
        <span className="flex items-center gap-2 mr-6">
          <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
          System: Ready
        </span>
        <span className="mr-6">Query: {searchQuery || 'None'}</span>
        <span>Zoom: 100%</span>
        <span className="ml-auto">Last Sync: {data?.timestamp ? format(new Date(data.timestamp), 'HH:mm:ss') : 'N/A'}</span>
      </footer>
    </div>
  );
}

